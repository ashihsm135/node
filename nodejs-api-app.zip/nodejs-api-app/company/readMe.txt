// Open your terminal and go into project and run these commands before start run server.js

npm init
npm install express --save
npm install express
npm install body-parser
npm install mongodb
npm install mongoose --save

// To run server.js use
 
  node server.js
